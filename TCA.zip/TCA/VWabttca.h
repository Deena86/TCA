//
//  VWabttca.h
//  TCA
//
//  Created by Deenadayal Loganathan on 12/3/14.
//  Copyright (c) 2014 Deena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YTPlayerView.h"


@interface VWabttca : UIViewController

@property(nonatomic, strong) IBOutlet YTPlayerView *abttcayou;

@property (weak, nonatomic) IBOutlet UILabel *lblabttca;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *menu;
@property (strong, nonatomic) IBOutlet UIView *Abttca;
@end
