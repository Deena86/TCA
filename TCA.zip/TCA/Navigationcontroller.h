//
//  Navigationcontroller.h
//  TCA
//
//  Created by Deenadayal Loganathan on 10/24/14.
//  Copyright (c) 2014 Deena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Navigationcontroller : UITableViewController

@end
