//
//  Commonclass.h
//  TCA
//
//  Created by Deenadayal Loganathan on 12/3/14.
//  Copyright (c) 2014 Deena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Commonclass : NSObject
- (NSString *) platformType:(NSString *)platform;
@end
