//
//  ViewController.h
//  TCA
//
//  Created by Deenadayal Loganathan on 10/24/14.
//  Copyright (c) 2014 Deena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIBarButtonItem *menu;
@property (weak, nonatomic) IBOutlet UILabel *testlbl;
@property (weak, nonatomic) IBOutlet UILabel *ttll;

@end

