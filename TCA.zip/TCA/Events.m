//
//  Events.m
//  TCA
//
//  Created by Deenadayal Loganathan on 2/4/15.
//  Copyright (c) 2015 Deena. All rights reserved.
//

#import "Events.h"
#import "SWRevealViewController.h"
#define UIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
@interface Events ()
{
    NSDictionary *dictEvnts;
    NSArray *arryEvnts;
}
@end

@implementation Events

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.menu.target=self.revealViewController;
    self.menu.action=@selector(revealToggle:);
    [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    self.tblvwEvntDtl.delegate=self;
    self.tblvwEvntDtl.dataSource=self;
    self.vwEvntdtl.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"TCAplain3d - 640x1136 - i5 a copy.png"]];
    NSString *strurl = [NSString stringWithFormat:@"http://app.tamilcatholicsusa.org/TCAService.svc/getevent"];
    NSURL *URL = [NSURL URLWithString:[strurl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSError *error=nil;
    NSData *data = [NSData dataWithContentsOfURL:URL options:NSDataReadingUncached error:& error];
    if(!error)
    {
        dictEvnts =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
        arryEvnts =[dictEvnts objectForKey:@"GetEventResult"];
    }
    NSDictionary *dictcat= [arryEvnts objectAtIndex:1];
    NSLog(@"%@",dictcat);
    self.lblEvnttitl.text =[dictcat objectForKey:@"EvntTitl"];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // Return the number of sections.
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    return arryEvnts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"test" forIndexPath:indexPath];

    
    //arrycatg =[arrysongs objectAtIndex:0];
    
    /* arrycatg=[arrysongs objectAtIndex:indexPath.row];
     ;*/
    
    
    
    
    
    // NSInteger *test =indexPath.row;
    
    cell.textLabel.text= @"test";
    /*[cell setBackgroundColor:[UIColor clearColor]];
    cell.textLabel.textColor = [UIColor lightGrayColor];*/
    return cell;
    
    
}



@end
