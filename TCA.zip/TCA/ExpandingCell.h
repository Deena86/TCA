//
//  ExpandingCell.h
//  TCA
//
//  Created by Deenadayal Loganathan on 11/1/14.
//  Copyright (c) 2014 Deena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExpandingCell : UITableViewCell
@property(strong,nonatomic) IBOutlet UILabel *dayLabel;
@property(strong,nonatomic) IBOutlet UILabel *dlythnklbl;
@end
