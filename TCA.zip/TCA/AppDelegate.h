//
//  AppDelegate.h
//  TCA
//
//  Created by Deenadayal Loganathan on 10/24/14.
//  Copyright (c) 2014 Deena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

