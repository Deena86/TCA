//
//  ExpandingCell.m
//  TCA
//
//  Created by Deenadayal Loganathan on 11/1/14.
//  Copyright (c) 2014 Deena. All rights reserved.
//

#import "ExpandingCell.h"

@implementation ExpandingCell
@synthesize dayLabel,dlythnklbl;


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
